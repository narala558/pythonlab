# motors
L298N motor driver
MD10C motor driver
BLDC 5015A - BLDC motor driver
BLD 300B - BLDC motor driver
ZWSK05 - BLDC motor driver
MDC100-050101 - BLDC motor driver


# ir sensor
GP2Y0A710K0F


# ultrasonic
SR-04 - Ultrasonic sensor
JSN SR-04T - Car back parking sensor


# bluetooth
HC-05 password: 1234
HM-10 password: 000000


# compass
LSM303DLHC - Marvemind hedge magnetometer -
HMC5883L - magnetometer -


# load balancer


# router
TL-WR841N - Tplink dual band router
