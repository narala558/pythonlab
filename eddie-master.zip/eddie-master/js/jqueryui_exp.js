$( "#accordion" ).accordion({
    collapsible: true
});
