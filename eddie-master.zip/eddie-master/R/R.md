Data structures
------------------


install package
---------------

```
install.packages("deseq")
```


read csv
---------

```
data = read.csv("anno.csv")
data[1:5, 1:4]
```


write df to file
-----------------

```
write.csv(df, 'foo.csv')
```
