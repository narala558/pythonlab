### My Programming Journal!

This repo contains sandbox programs, dot files and other terminal commands.


### Setup

```sh
sh -c "$(wget https://raw.githubusercontent.com/ChillarAnand/01/master/ubuntu/bin/start.sh -O -)"
```

### Todo

Pybluez-tools
openssl
zsh suggestions
venv setup
network-manager

Project name
ansible
notebook – split utils
install ipython
p3 pip def profi
curl
https://github.com/SergKolo/lks-indicator/issues/new

Emacs:
use package
