#! /data/data/com.termux/files/usr/bin/sh

ls

# mount -o remount,rw /
# mount  -o remount,rw /system
