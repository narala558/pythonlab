#! /system/bin/sh

export LD_LIBRARY_PATH=/data/data/com.termux/files/usr/lib
export PATH=$PATH:/data/data/com.termux/files/usr/bin

/data/data/com.termux/files/usr/bin/bash "$@"
