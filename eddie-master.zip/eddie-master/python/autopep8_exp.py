print('a',

      'b')


super().__init__(
    "aaaaaaaaaaaaaaaaaaaaaaaa")
