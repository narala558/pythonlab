XOR <-> (OR - NAND) -> AND



To find minima of a complex function, algebra is  hard.
We can use gradient descent to calculate minima without getting the derivative of the function.






Autoencoder - find the most efficient compact representation (encoding) for input data.


Sigmoid - vanishing gradient problem
Relu vs sigmdoid - sparsity and a reduced likelihood of vanishing gradient.


Neurons in the earlier layers learn very slowly. Earlier layers are the slowest to train.



RNN - Has context.
RNN - vanishing gradient problem

LSTM
- has memory cell
- more complex structure, more weights and needs more resources to train




Adversarial attacks
