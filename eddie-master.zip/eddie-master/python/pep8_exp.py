if True:
        print('true')
