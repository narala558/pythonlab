import sys


def foo():
    return


print(sys.path)
