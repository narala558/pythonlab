from keras.models import Sequential

model = Sequential()
