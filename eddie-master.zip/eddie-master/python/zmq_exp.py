import zmq

print(zmq.pyzmq_version())
