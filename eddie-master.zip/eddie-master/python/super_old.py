# some random comment
# some random comment
@some_decorator(
    foo, bar, baz
)
class Foo:
    def __init__(self):
        super(Foo, self).__init__()

    def foo(self):
        class Test():
            def check(self, **kwargs):
                errors = super(Test, self).check(**kwargs)


class Test():
    def check(self, **kwargs):
        errors = super(MyBookAdmin, cls).check(**kwargs)
