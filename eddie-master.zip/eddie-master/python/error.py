import ptb; ptb.enable()

x = '!'
raise error
