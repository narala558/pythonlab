x = '12'
y = x  # type: int
print(type(y))
