def foo():
    x = [1, 2, 3, 3, 4]
    import pdb; pdb.set_trace()
    print(x)

foo()
