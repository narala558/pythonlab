import logging


a = 'a'
logger = logging.getLogger(__name__)
logger.info('Starting training')
