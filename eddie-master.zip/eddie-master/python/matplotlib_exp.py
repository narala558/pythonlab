# in notebooks
# %matplotlib inline

# in program
get_ipython().magic('matplotlib inline')
