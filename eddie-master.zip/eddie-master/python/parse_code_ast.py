# import ast

# import astor

# p = astor.code_to_ast.parse_file('super_test.py')

# print(p)

# p.body[0].body = [ ast.parse("return 42").body[0] ] # Replace function body with "return 42"
# print(codegen.to_source(p))


s = open('super_test.py').read()
s =
