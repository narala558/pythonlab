char c = 'a';


void main() {

}
